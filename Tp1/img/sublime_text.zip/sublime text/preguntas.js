var componentes = {
  "Kernel": "Es el núcleo del sistema operativo, encargado de gestionar los recursos del hardware.",
  "Interfaz gráfica de usuario": "Permite la interacción con el sistema operativo a través de elementos visuales.",
  "Sistema de archivos": "Organiza y almacena los archivos en el disco duro de manera estructurada.",
  "Gestor de memoria": "Administra el uso de la memoria RAM para optimizar el rendimiento del sistema.",
  "Controlador de dispositivo": "Facilita la comunicación entre el hardware y el sistema operativo."
};

var root = document.getElementById("options");
var questionDiv = document.getElementById("question");

function verificar_seleccion(opcion_seleccionada, boton) {
  var pregunta = Object.entries(componentes)[indice_pregunta];
  if (opcion_seleccionada == pregunta[0]) {
    alert("¡Respuesta correcta!");
    boton.classList.add('correcto'); // Agrega la clase 'correcto' al botón
    mostrar_siguiente_preguntaDespuesDeCincoSegundos();
  } else {
    alert("Respuesta incorrecta. Inténtalo de nuevo.");
    boton.classList.add('incorrecto'); // Agrega la clase 'incorrecto' al botón
  }
}

function mostrar_siguiente_preguntaDespuesDeCincoSegundos() {
  setTimeout(mostrar_siguiente_pregunta, 1000); // 5000 milisegundos = 5 segundos
}

function mostrar_siguiente_pregunta() {
  if (indice_pregunta < Object.keys(componentes).length - 1) {
    indice_pregunta++;
    var pregunta = Object.entries(componentes)[indice_pregunta];
    questionDiv.textContent = pregunta[1];
    root.innerHTML = "";
    var opciones = Object.keys(componentes);
    opciones.sort(() => Math.random() - 0.5); // Mezclar las opciones
    opciones.forEach(opcion => {
      var button = document.createElement("button");
      button.textContent = opcion;
      button.onclick = function() { verificar_seleccion(opcion, button); };
      root.appendChild(button);
    });
  } else {
    alert("¡Has completado todas las preguntas!");
    reiniciar_juego();
  }
}

function reiniciar_juego() {
  indice_pregunta = 0;
  mostrar_siguiente_pregunta();
}

var indice_pregunta = 0;
mostrar_siguiente_pregunta();

