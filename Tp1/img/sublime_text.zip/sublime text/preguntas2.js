var componentes2 = {
  "Algoritmo": "Es un conjunto ordenado de operaciones sistemáticas que permite hacer un cálculo y hallar la solución de un problema.",
  "Ciclo de vida del software": "Comprende todas las etapas por las que pasa un programa desde su concepción hasta su retirada.",
  "Depuración de código": "Proceso que consiste en encontrar y corregir errores o defectos presentes en el código de un programa.",
  "Programación orientada a objetos": "Paradigma de programación que utiliza objetos y clases para modelar y resolver problemas.",
  "Lenguaje de programación": "Conjunto de reglas, símbolos y convenciones que permite escribir programas informáticos."
};

var root2 = document.getElementById("options2");
var questionDiv2 = document.getElementById("question2");

function verificar_seleccion2(opcion_seleccionada, boton) {
  var pregunta = Object.entries(componentes2)[indice_pregunta];
  if (opcion_seleccionada == pregunta[0]) {
    alert("¡Respuesta correcta!");
    boton.classList.add('correcto'); // Agrega la clase 'correcto' al botón
    mostrar_siguiente_preguntaDespuesDeCincoSegundos();
  } else {
    alert("Respuesta incorrecta. Inténtalo de nuevo.");
    boton.classList.add('incorrecto'); // Agrega la clase 'incorrecto' al botón
  }
}

function mostrar_siguiente_preguntaDespuesDeCincoSegundos() {
  setTimeout(mostrar_siguiente_pregunta2, 1000); // 5000 milisegundos = 5 segundos
}

function mostrar_siguiente_pregunta2() {
  if (indice_pregunta < Object.keys(componentes2).length - 1) {
    indice_pregunta++;
    var pregunta = Object.entries(componentes2)[indice_pregunta];
    questionDiv2.textContent = pregunta[1];
    root2.innerHTML = "";
    var opciones = Object.keys(componentes2);
    opciones.sort(() => Math.random() - 0.5); // Mezclar las opciones
    opciones.forEach(opcion => {
      var button = document.createElement("button");
      button.textContent = opcion;
      button.onclick = function() { verificar_seleccion2(opcion, button); };
      root2.appendChild(button);
    });
  } else {
    alert("¡Has completado todas las preguntas!");
    reiniciar_juego2();
  }
}

function reiniciar_juego2() {
  indice_pregunta = 0;
  mostrar_siguiente_pregunta2();
}

var indice_pregunta = 0;
mostrar_siguiente_pregunta2();
